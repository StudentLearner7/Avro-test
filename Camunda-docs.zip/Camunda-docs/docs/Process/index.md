# Process in Camunda 8

Introduction to BPMN Processes in Camunda 8.

## Overview

BPMN Processes are at the heart of workflow automation in Camunda 8. This section introduces the concept of BPMN processes, including how to model them using BPMN 2.0 notation.

## Key Concepts

- BPMN Elements
- Process Modeling
- Deployment
- Execution

## Next Steps

Learn how to manage [Process Instances](../ProcessInstance/index.md).
