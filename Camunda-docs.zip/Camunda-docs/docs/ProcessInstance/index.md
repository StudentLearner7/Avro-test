# ProcessInstance in Camunda 8

Introduction to managing ProcessInstances in Camunda 8.

## Overview

ProcessInstances represent running instances of BPMN processes. This section explains how to manage and interact with these instances in Camunda 8.

## Key Concepts

- Starting ProcessInstances
- Instance States
- Variables
- Instance Management

## Next Steps

Understand how to work with [Tasks](../Task/index.md).
