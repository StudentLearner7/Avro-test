# Task in Camunda 8

Introduction to Tasks in Camunda 8.

## Overview

Tasks are units of work within a ProcessInstance. This section covers the types of tasks in Camunda 8 and how to manage them.

## Key Concepts

- User Tasks
- Service Tasks
- Task Assignment
- Completing Tasks

## Next Steps

Review [Process modeling](../Process/index.md) to better understand how tasks fit into BPMN processes.
