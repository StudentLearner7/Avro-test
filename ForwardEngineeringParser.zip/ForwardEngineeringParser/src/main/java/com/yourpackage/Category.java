package com.yourpackage;

import jakarta.persistence.*;
import java.util.Set;

@Entity
public class Category {
    private Long id;
    private String name;
    @OneToMany(mappedBy = "category")
    private Set<Product> products;
}
