package com.yourpackage;

import jakarta.persistence.*;

@Entity
public class Product {
    private Long id;
    private String name;
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;
}
