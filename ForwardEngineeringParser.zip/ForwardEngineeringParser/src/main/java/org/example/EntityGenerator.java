package org.example;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.io.File;

public class EntityGenerator {
    public static void main(String[] args) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            EntityData entityData = objectMapper.readValue(
                    EntityGenerator.class.getResourceAsStream("/entities.json"),
                    EntityData.class
            );

            for (Entity entity : entityData.getEntities()) {
                String packageName = "com.yourpackage"; // Replace with your package name
                String entityClassName = entity.getName();
                String packagePath = packageName.replace(".", "/");
                String directoryPath = "src/main/java/" + packagePath;

                // Create directories if they don't exist
                new File(directoryPath).mkdirs();

                String filename = directoryPath + "/" + entityClassName + ".java";

                try (Writer writer = new FileWriter(filename)) {
                    writer.write("package " + packageName + ";\n\n");
                    writer.write("import jakarta.persistence.*;\n");

                    // Check the JSON input for collection type
                    boolean hasSet = checkForSetInJson(entity); // Implement this method
                    boolean hasList = checkForListInJson(entity); // Implement this method

                    if (hasSet) {
                        writer.write("import java.util.Set;\n");
                    }

                    if (hasList) {
                        writer.write("import java.util.List;\n");
                    }

                    writer.write("\n");

                    writer.write("@Entity\n");
                    writer.write("public class " + entityClassName + " {\n");

                    for (Field field : entity.getFields()) {
                        if (field.getAssociation() == null) {
                            writer.write("    private " + field.getType() + " " + field.getName() + ";\n");
                        } else {
                            if (field.getAssociation().equals("OneToMany")) {
                                writer.write("    @OneToMany(mappedBy = \"" + entityClassName.toLowerCase() + "\")\n");
                                writer.write("    private " + field.getType() + " " + field.getName() + ";\n");
                            } else if (field.getAssociation().equals("ManyToOne")) {
                                writer.write("    @ManyToOne\n");
                                writer.write("    @JoinColumn(name = \"" + field.getName().toLowerCase() + "_id\")\n");
                                writer.write("    private " + field.getType() + " " + field.getName() + ";\n");
                            }
                        }
                    }

                    writer.write("}\n");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean checkForListInJson(Entity entity) {
        for (Field field : entity.getFields()) {
                if (field.getType().contains("List")) {
                return true;
            }
        }
        return false;
    }

    private static boolean checkForSetInJson(Entity entity) {
        for (Field field : entity.getFields()) {
            if (field.getType().contains("Set")) {
                return true;
            }
        }
        return false;
    }

    // Implement checkForSetInJson and checkForListInJson methods to parse JSON and check for collection types.
}




class EntityData {
    private List<Entity> entities;

    public List<Entity> getEntities() {
        return entities;
    }

    public void setEntities(List<Entity> entities) {
        this.entities = entities;
    }
}

class Entity {
    private String name;
    private List<Field> fields;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Field> getFields() {
        return fields;
    }

    public void setFields(List<Field> fields) {
        this.fields = fields;
    }
}

class Field {
    private String name;
    private String type;
    private String association;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAssociation() {
        return association;
    }

    public void setAssociation(String association) {
        this.association = association;
    }
}
