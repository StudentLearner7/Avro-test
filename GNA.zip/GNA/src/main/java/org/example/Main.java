package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Main {

    public static void main(String[] args) {

        // Get the necessary beans
        ApplicationContext context = SpringApplication.run(Main.class, args);
        CustomerService customerService = context.getBean(CustomerService.class);
        OrderService orderService = context.getBean(OrderService.class);

        // Insert data
        Customer customer = new Customer();
        customer.setCustomerName("John Doe");
        customerService.saveCustomer(customer);

        Order order = new Order();
        order.setOrderNumber("ORD123");
        order.setCustomer(customer);
        orderService.saveOrder(order);

        System.out.println("Data inserted successfully!");
    }
}
