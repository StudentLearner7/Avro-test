package  com.abc.custom;
import com.abc.JDLBaseListener;
import com.abc.JDLParser;
import java.util.HashMap;
import java.util.Map;

public class CustomJDLListener extends JDLBaseListener {

    private Map<String, String> entityFields = new HashMap<>();

    @Override
    public void enterEntityDeclaration(JDLParser.EntityDeclarationContext ctx) {
        String entityName = ctx.entityName().getText();
        StringBuilder entityCode = new StringBuilder();

        entityCode.append("@Entity\n");
        entityCode.append("public class ").append(entityName).append(" {\n");

        ctx.fieldDeclaration().forEach(field -> {
            String fieldName = field.fieldName().getText();
            String fieldType = field.fieldType().getText();
            entityCode.append("    private ").append(fieldType).append(" ").append(fieldName).append(";\n");

            // Store field information for later use in relationships
            entityFields.put(entityName + "." + fieldName, fieldType);
        });

        entityCode.append("}\n");
        System.out.println(entityCode.toString());
    }

    @Override
    public void enterRelationshipDeclaration(JDLParser.RelationshipDeclarationContext ctx) {
        if (ctx.relationshipType().getText().equals("OneToOne")) {
            String sourceEntity = ctx.relationshipBody().sourceEntity().getText();
            String fieldName = ctx.relationshipBody().fieldName().getText();
            String targetEntity = ctx.relationshipBody().targetEntity().getText();

            // Retrieve the field type from previously stored entity fields
            String fieldType = entityFields.getOrDefault(sourceEntity + "." + fieldName, "Object");

            System.out.println("In entity " + sourceEntity + ", add the following field for OneToOne relationship:");
            System.out.println("@OneToOne");
            System.out.println("private " + fieldType + " " + fieldName + ";");
        }
    }

    // Additional methods for other JDL features as needed
}
