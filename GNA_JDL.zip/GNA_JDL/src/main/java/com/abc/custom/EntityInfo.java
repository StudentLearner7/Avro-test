package com.abc.custom;

import java.util.ArrayList;
import java.util.List;

public class EntityInfo {
    private String name;
    private List<FieldInfo> fields = new ArrayList<>();
    private List<RelationshipInfo> relationships = new ArrayList<>();

    public EntityInfo(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public List<FieldInfo> getFields() {
        return fields;
    }

    public void addField(FieldInfo field) {
        fields.add(field);
    }

    public List<RelationshipInfo> getRelationships() {
        return relationships;
    }

    public void addRelationship(RelationshipInfo relationship) {
        relationships.add(relationship);
    }
}
