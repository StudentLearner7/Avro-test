package com.abc.custom;

import com.abc.JDLLexer;
import com.abc.JDLParser;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class Main {
    public static void main(String[] args) throws Exception {
        // Assuming args[0] is the path to your JDL file
        String inputFile = "/abc.jdl"; // Replace with your JDL file path

        ANTLRInputStream input = new ANTLRInputStream(Main.class.getResourceAsStream(inputFile));

        JDLLexer lexer = new JDLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        JDLParser parser = new JDLParser(tokens);

        ParseTree tree = parser.jdlFile();
        ParseTreeWalker walker = new ParseTreeWalker();
        CustomJDLListener listener = new CustomJDLListener();
        walker.walk(listener, tree);
    }
}
