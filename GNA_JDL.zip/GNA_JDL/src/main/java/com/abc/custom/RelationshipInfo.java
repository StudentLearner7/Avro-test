package com.abc.custom;

public class RelationshipInfo {
    private String type;
    private String fromEntity;
    private String fromField;
    private String toEntity;

    public RelationshipInfo(String type, String fromEntity, String fromField, String toEntity) {
        this.type = type;
        this.fromEntity = fromEntity;
        this.fromField = fromField;
        this.toEntity = toEntity;
    }

    public String getType() {
        return type;
    }

    public String getFromEntity() {
        return fromEntity;
    }

    public String getFromField() {
        return fromField;
    }

    public String getToEntity() {
        return toEntity;
    }
}
