package com.example.demo;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.data.repository.CrudRepository;

import javax.persistence.EmbeddedId;
import javax.persistence.Id;
import javax.persistence.IdClass;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;


public class RepositoryGenerator {

    public static void main(String[] args) throws IOException, TemplateException {
        // Configure FreeMarker
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

        // Specify the package names and directories
        String entityPackage = "com.example.entities";
        String repositoryPackage = "com.example.repository";
        String outputDirectory = "./src/main/java/" + repositoryPackage.replace('.', '/');

        // Create the output directory if it doesn't exist
        new File(outputDirectory).mkdirs();

        String[] entityClassNames = getEntityClassNames(entityPackage);

        // Process each entity class
        for (String entityClassName : entityClassNames) {
            String entitySimpleName = entityClassName.substring(entityClassName.lastIndexOf('.') + 1);
            String repositorySimpleName = entitySimpleName + "Repository";
            String repositoryClassName = repositoryPackage + "." + repositorySimpleName;

            // Load the entity class
            Class<?> entityClass;
            try {
                entityClass = Class.forName(entityClassName);
            } catch (ClassNotFoundException e) {
                System.err.println("Error loading entity class: " + entityClassName);
                continue;
            }

            // Determine the primary key type
            Class<?> primaryKeyType = null;

            // Check for @IdClass annotation
            if (entityClass.isAnnotationPresent(IdClass.class)) {
                primaryKeyType = entityClass.getAnnotation(IdClass.class).value();
            }

            // Check for @Id or @EmbeddedId annotation
            for (Field field : entityClass.getDeclaredFields()) {
                if (field.isAnnotationPresent(Id.class) || field.isAnnotationPresent(EmbeddedId.class)) {
                    primaryKeyType = field.getType();
                    break;
                }
            }

            if (primaryKeyType == null) {
                System.err.println("No primary key found for entity: " + entitySimpleName);
                continue;
            }

            // Prepare the data model for the template
            Map<String, Object> dataModel = new HashMap<>();
            dataModel.put("entityPackage", entityPackage);
            dataModel.put("entitySimpleName", entitySimpleName);
            dataModel.put("repositoryPackage", repositoryPackage);
            dataModel.put("repositorySimpleName", repositorySimpleName);
            dataModel.put("repositoryClassName", repositoryClassName);
            dataModel.put("crudRepositoryClassImport", CrudRepository.class.getName());
            dataModel.put("crudRepositorySimpleName", "CrudRepository");
            dataModel.put("primaryKeyTypeSimpleName", primaryKeyType.getSimpleName());
            dataModel.put("primaryKeyTypeClassImport", primaryKeyType.getName());


            // Load the template
            Template template = loadTemplate("repository.ftl");


            // Generate the repository interface file
            FileWriter fileWriter = new FileWriter(outputDirectory + "/" + repositorySimpleName + ".java");
            template.process(dataModel, fileWriter);
            fileWriter.close();

            System.out.println("Generated: " + repositoryClassName);
        }


        System.out.println("Repository generation completed.");
    }


    private static Template loadTemplate(String templateName) throws IOException {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

        cfg.setClassForTemplateLoading(RepositoryGenerator.class, "/templates");

        return cfg.getTemplate(templateName);
    }


    private static String[] getEntityClassNames(String entityPackage) throws IOException {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        String packagePath = entityPackage.replace('.', '/');
        Enumeration<URL> resources = classLoader.getResources(packagePath);
        List<String> classNames = new ArrayList<>();

        while (resources.hasMoreElements()) {
            URL resource = resources.nextElement();
            String protocol = resource.getProtocol();

            if ("file".equals(protocol)) {
                String filePath = URLDecoder.decode(resource.getFile(), "UTF-8");
                findClassNamesInDirectory(classNames, entityPackage, filePath);
            } else if ("jar".equals(protocol)) {
                JarURLConnection jarURLConnection = (JarURLConnection) resource.openConnection();
                findClassNamesInJar(classNames, entityPackage, jarURLConnection);
            }
        }

        return classNames.toArray(new String[0]);
    }

    private static void findClassNamesInDirectory(List<String> classNames, String entityPackage, String directoryPath) {
        File directory = new File(directoryPath);
        File[] files = directory.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    String subPackage = entityPackage + "." + file.getName();
                    findClassNamesInDirectory(classNames, subPackage, file.getAbsolutePath());
                } else if (file.getName().endsWith(".class")) {
                    String className = entityPackage + "." + file.getName().replace(".class", "");
                    classNames.add(className);
                }
            }
        }
    }

    private static void findClassNamesInJar(List<String> classNames, String entityPackage, JarURLConnection jarURLConnection) throws IOException {
        JarFile jarFile = jarURLConnection.getJarFile();
        Enumeration<JarEntry> jarEntries = jarFile.entries();

        while (jarEntries.hasMoreElements()) {
            JarEntry jarEntry = jarEntries.nextElement();
            String entryName = jarEntry.getName();

            if (entryName.startsWith(entityPackage) && entryName.endsWith(".class")) {
                String className = entryName.replace('/', '.').replace(".class", "");
                classNames.add(className);
            }
        }
    }


}
