package com.example.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Order {
    @EmbeddedId
    private OrderId id;
    private String orderDetails;

    // constructors, getters, setters, and other methods

    // additional fields and methods
}
