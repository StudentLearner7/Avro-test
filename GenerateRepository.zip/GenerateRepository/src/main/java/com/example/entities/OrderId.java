package com.example.entities;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class OrderId implements Serializable {
    private Long orderId;
    private Long customerId;

    // constructors, getters, setters, and other methods

    // equals and hashCode methods
}
