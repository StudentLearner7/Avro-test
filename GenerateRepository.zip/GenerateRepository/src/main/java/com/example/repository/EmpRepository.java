package com.example.repository;

import com.example.entities.Emp;
import org.springframework.data.repository.CrudRepository;
import java.lang.String;

public interface EmpRepository extends CrudRepository<Emp, String> {
    // Custom query methods can be defined here
}
