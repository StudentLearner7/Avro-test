package com.example.repository;

import com.example.entities.Order;
import org.springframework.data.repository.CrudRepository;
import com.example.entities.OrderId;

public interface OrderRepository extends CrudRepository<Order, OrderId> {
    // Custom query methods can be defined here
}
