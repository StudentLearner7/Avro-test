package com.example.repository;

import com.example.entities.User;
import org.springframework.data.repository.CrudRepository;
import java.lang.Long;

public interface UserRepository extends CrudRepository<User, Long> {
    // Custom query methods can be defined here
}
