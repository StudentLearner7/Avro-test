package  com.abc.custom;

import com.abc.JDLBaseListener;
import com.abc.JDLParser;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.HashSet;
import java.util.Set;

public class CustomJDLListener extends JDLBaseListener {

    private Map<String, String> entityFields = new HashMap<>();
    private Set<String> entities = new HashSet<>();

    @Override
    public void enterEntityDeclaration(JDLParser.EntityDeclarationContext ctx) {
        String entityName = ctx.entityName().getText();
        entities.add(entityName);

        ctx.fieldDeclaration().forEach(field -> {
            String fieldName = field.fieldName().getText();
            String fieldType = field.fieldType().getText();

            // Storing field information
            entityFields.put(entityName + "." + fieldName, fieldType);
        });
    }

    private String inferFieldType(String entity, String fieldName) {
        // Return the correct field type, or 'Object' as default
        return entityFields.getOrDefault(entity + "." + fieldName, "Object");
    }

    @Override
    public void enterRelationshipDeclaration(JDLParser.RelationshipDeclarationContext ctx) {
        String relationshipType = ctx.relationshipType().getText();
        String sourceEntity = ctx.relationshipBody().sourceEntity().getText();
        String targetEntity = ctx.relationshipBody().targetEntity().getText();

        // Extracting optional relationship fields
        String sourceFieldName = getOptionalFieldName(ctx.relationshipBody().relationshipField(0));
        String targetFieldName = getOptionalFieldName(ctx.relationshipBody().relationshipField(1));

        System.out.println("Debug: Source field name: " + sourceFieldName);
        System.out.println("Debug: Target field name: " + targetFieldName);

        switch (relationshipType) {
            case "OneToOne":
                handleOneToOne(sourceEntity, sourceFieldName, targetEntity, targetFieldName);
                break;
            case "OneToMany":
                handleOneToMany(sourceEntity, sourceFieldName, targetEntity, targetFieldName);
                break;
            case "ManyToOne":
                handleManyToOne(sourceEntity, sourceFieldName, targetEntity, targetFieldName);
                break;
            case "ManyToMany":
                handleManyToMany(sourceEntity, sourceFieldName, targetEntity, targetFieldName);
                break;
            default:
                System.out.println("Unhandled relationship type: " + relationshipType);
        }
    }

    private String getOptionalFieldName(JDLParser.RelationshipFieldContext context) {
        if (context != null) {
            JDLParser.FieldNameContext fieldNameCtx = context.fieldName();
            if (fieldNameCtx != null) {
                return fieldNameCtx.getText();
            } else {
                System.out.println("Debug: Field name context is null in relationship field.");
            }
        } else {
            System.out.println("Debug: Relationship field context is null.");
        }
        return null;
    }



    private void handleOneToOne(String sourceEntity, String sourceFieldName, String targetEntity, String targetFieldName) {
        if (!entities.contains(sourceEntity) || !entities.contains(targetEntity)) {
            System.out.println("Entity not found for OneToOne relationship.");
            return;
        }

        // In a one-to-one relationship, the field type for each entity is the other entity
        String sourceFieldType = targetEntity; // Field type of source entity is the target entity
        String targetFieldType = sourceEntity; // Field type of target entity is the source entity

        // Generate the code for the source entity
        System.out.println("In entity " + sourceEntity + ", add the following field for OneToOne relationship:");
        System.out.println("@OneToOne");
        if (targetFieldName != null) {
            // Bidirectional - specify the mappedBy attribute
            System.out.println("private " + sourceFieldType + " " + sourceFieldName + ";\n");
        } else {
            // Unidirectional
            System.out.println("private " + sourceFieldType + " " + sourceFieldName + ";");
        }

        // If bidirectional, generate the code for the target entity
        if (targetFieldName != null) {
            System.out.println("In entity " + targetEntity + ", add the following field for OneToOne relationship:");
            System.out.println("@OneToOne(mappedBy = \"" + sourceFieldName + "\")");
            System.out.println("private " + targetFieldType + " " + targetFieldName + ";");
        }
    }




    private void handleOneToMany(String sourceEntity, String sourceFieldName, String targetEntity, String targetFieldName) {
        if (!entities.contains(sourceEntity) || !entities.contains(targetEntity)) {
            System.out.println("Entity not found for OneToMany relationship: " + sourceEntity + " to " + targetEntity);
            return;
        }

        if (targetFieldName == null) {
            System.out.println("Target field name is missing in OneToMany relationship from " + sourceEntity + " to " + targetEntity);
            return;
        }

        System.out.println("In entity " + sourceEntity + ", add the following field for OneToMany relationship:");
        System.out.println("@OneToMany(mappedBy = \"" + targetFieldName + "\")");
        System.out.println("private Set<" + targetEntity + "> " + pluralize(targetEntity.toLowerCase()) + " = new HashSet<>();");
    }


    private void handleManyToOne(String sourceEntity, String sourceFieldName, String targetEntity, String targetFieldName) {
        if (!entities.contains(sourceEntity) || !entities.contains(targetEntity)) {
            System.out.println("Entity not found for ManyToOne relationship.");
            return;
        }
        System.out.println("In entity " + sourceEntity + ", add the following field for ManyToOne relationship:");
        System.out.println("@ManyToOne");
        System.out.println("private " + targetEntity + " " + sourceFieldName + ";");
    }

    private void handleManyToMany(String sourceEntity, String sourceFieldName, String targetEntity, String targetFieldName) {
        if (!entities.contains(sourceEntity) || !entities.contains(targetEntity)) {
            System.out.println("Entity not found for ManyToMany relationship.");
            return;
        }
        System.out.println("In entity " + sourceEntity + ", add the following field for ManyToMany relationship:");
        System.out.println("@ManyToMany");
        System.out.println("private Set<" + targetEntity + "> " + sourceFieldName + "s = new HashSet<>();");
    }

    private String pluralize(String name) {
        return name.endsWith("s") ? name : name + "s";
    }
}
